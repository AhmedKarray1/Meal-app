import 'package:flutter/material.dart';
import 'package:meals_app/models/meal.dart';

import '../widgets/meal_item.dart';

class FavoriteScreen extends StatelessWidget {
final List<Meal> favoritemeals;
  FavoriteScreen(this.favoritemeals);

  @override
  Widget build(BuildContext context) {
    if (favoritemeals.isEmpty){
          return Center(child: Text("You have no favorites meals yet - start adding some!",style: Theme.of(context).textTheme.bodyText1,),);



    }
    else{
      return


      ListView.builder(
itemBuilder: ((context, index) {

return MealItem(id:favoritemeals[index].id
,title:favoritemeals[index].title ,imageUrl:favoritemeals[index].imageUrl ,duration:favoritemeals[index].duration ,complexity:favoritemeals[index].complexity ,affordability:favoritemeals[index].affordability ,ingredients:favoritemeals[index].ingredients,steps:favoritemeals[index].steps,




);

} ),
itemCount:favoritemeals.length ,



     );
    }





  }
}