import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class MealDetailScreen extends StatelessWidget {
  final Function _toggleFavorite;
  final Function isFavorite;

  MealDetailScreen(this._toggleFavorite, this.isFavorite);

  Widget buildSectionTitle(BuildContext ctx, String title) {
    return Center(
        child: Text(
      title,
      style: Theme.of(ctx).textTheme.bodyText1,
    ));
  }

  Widget buildContainer(Widget child) {
    return Container(
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(10)),
        margin: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
        padding: EdgeInsets.all(10),
        height: 150,
        width: 300,
        child: child);
  }

  static const routeName = '/meal-detail';
  @override
  Widget build(BuildContext context) {
    final routeArgs =
        ModalRoute.of(context).settings.arguments as Map<String, dynamic>;
    final mealId = routeArgs['id'];
    final mealTitle = routeArgs['title'];
    final mealImageUrl = routeArgs['imageUrl'];
    final mealIngredients = routeArgs['ingredients'] as List<String>;
    final mealSteps = routeArgs['steps'] as List;

    return Scaffold(
      appBar: AppBar(
        title: Text(mealTitle),
      ),
      body: ListView(
        children: [
          Container(
              height: 300,
              width: double.infinity,
              child: Image.network(
                mealImageUrl,
                fit: BoxFit.cover,
              )),
          SizedBox(
            height: 10,
          ),
          buildSectionTitle(context, "Ingredients"),
          buildContainer(
            ListView.builder(
              itemCount: mealIngredients.length,
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  color: Theme.of(context).accentColor,
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: Text(mealIngredients[index]),
                  ),
                );
              },
            ),
          ),
          buildSectionTitle(context, 'Steps'),
          buildContainer(ListView.builder(
            itemBuilder: (context, index) => Column(
              children: [
                ListTile(
                  leading: CircleAvatar(child: Text('# ${(index + 1)}')),
                  title: Text(mealSteps[index]),
                ),
                Divider(
                  color: Colors.black,
                )
              ],
            ),
            itemCount: mealSteps.length,
          ))
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(isFavorite(mealId) ? Icons.star : Icons.star_border),
        onPressed:()=> _toggleFavorite(mealId),
      ),
    );
  }
}
