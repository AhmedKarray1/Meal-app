import 'package:flutter/material.dart';
import 'package:meals_app/widgets/main_drawer.dart';

class FiltersScreen extends StatefulWidget {
  final Function saveFilters;
  final Map<String ,bool> currentFilter;
  FiltersScreen(this.currentFilter,this.saveFilters);

  static const routeName = '/filters';

  @override
  State<FiltersScreen> createState() => _FiltersScreenState();
}

class _FiltersScreenState extends State<FiltersScreen> {
  var _glutenFree = false;
  var _vegetarian = false;
  var _vegan = false;
  var _lactoseFree = false;

  @override
  void initState() {
    _glutenFree=widget.currentFilter['gluten'];
    _vegetarian=widget.currentFilter['vegetarian'];
    _vegan=widget.currentFilter['vegan'];
    _lactoseFree=widget.currentFilter['lactose'];

    
    super.initState();
  }
  Widget _buildSwtchListTile(
      String title, String subtitle, bool currentValue, Function updateValue) {
    return SwitchListTile(
      value: currentValue?? false,
      onChanged: updateValue,
      title: Text(title),
      subtitle: Text(subtitle),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Your Filters"),
          actions: [
            IconButton(
              onPressed: (){
                final selectedFilters={'gluten':_glutenFree,'lactose':_lactoseFree,'vegetarian':_vegetarian,'vegan':_vegan};

                
                
                
                
                
                
                
                widget.saveFilters(selectedFilters);},
              
              
              
              icon: Icon(Icons.save),
            )
          ],
        ),
        drawer: MainDrawer(),
        body: Column(
          children: [
            Container(
                width: double.infinity,
                padding: EdgeInsets.all(25),
                child: Text(
                  "Adjust your meal selection ",
                  style: Theme.of(context).textTheme.bodyText1,
                  textAlign: TextAlign.center,
                )),
            Expanded(
                child: ListView(
              children: [
                _buildSwtchListTile("Gluten-free",
                    "Only include gluten-free meals", _glutenFree, (newvalue) {
                  setState(() {
                    _glutenFree = newvalue;
                 
                  });
                }),
                _buildSwtchListTile(
                    "Lactose-free",
                    "Only include Lactose-free meals",
                    _lactoseFree, (newvalue) {
                  setState(() {
                    _lactoseFree = newvalue;
                  });
                }),
                _buildSwtchListTile(
                    "Vegetarian", "Only include vegetarian meals", _vegetarian,
                    (newvalue) {
                  setState(() {
                    _vegetarian = newvalue;
                  });
                }),
                _buildSwtchListTile("Vegan", "Only include vegan meals", _vegan,
                    (newvalue) {
                  setState(() {
                    _vegan = newvalue;
                  });
                }),
              ],
            ))
          ],
        ));
  }
}
