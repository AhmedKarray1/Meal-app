import 'package:flutter/material.dart';
import 'package:meals_app/screens/filters_screen.dart';

class MainDrawer extends StatelessWidget {
  Widget buildListTile(String title,IconData icon,Function tapHandler)
  { return ListTile(leading: Icon(icon,size: 26,
      ),title: Text(title,style: TextStyle(fontFamily: 'RobotoCondensed'),),
      
      onTap: tapHandler,
      
      
      );




  }


  @override
  Widget build(BuildContext context) {
    return Drawer(child:Column(children: [
      Container(padding: EdgeInsets.only(left:15, top: 40 )
        
        
        
        ,height: 120,width: double.infinity,
      color: Theme.of(context).accentColor,child:Text("Cooking Up!",style: TextStyle(fontSize: 30,color: Theme.of(context).primaryColor,fontWeight: FontWeight.w900,


      ) ,) ,),
      SizedBox(height: 20,),
     buildListTile("Meals"
      , Icons.restaurant,(){
        Navigator.of(context).pushReplacementNamed('/');




      }),
        SizedBox(height: 5,),
      buildListTile("Filters", Icons.settings,(){

Navigator.of(context).pushReplacementNamed(FiltersScreen.routeName);

      })














    ],) );
  }
}